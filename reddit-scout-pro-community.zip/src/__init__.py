"""Reddit Explorer - Comprehensive Reddit analysis and discovery tool."""

__version__ = "1.0.0"
__author__ = "Martin"
__description__ = "Reddit Explorer - Comprehensive Reddit analysis and discovery tool" 